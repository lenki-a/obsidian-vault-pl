---
kategoria: "[[Źródła wiedzy]]"
data: 2023-06-16
autor:
  - "[[Gabriel Krynicki]]"
  - "[[Arkadiusz Lenkiewicz]]"
tags:
  - uran
  - energia
  - atom
---
W 2007 roku bańka uranowa - bo tak nazwano ten okres, była niemal pionowym wzrostem cen naturalnego uranu, który osiągnął szczytowy poziom około 135 USD/funt w połowie 2007 roku, zbiegając się w czasie ze znacznymi wzrostami cen akcji firm zajmujących się wydobyciem i poszukiwaniem uranu. Przyczyną tego wzrostu pomijając uranowy szum medialny było zalanie kopalni Cameco Cigar Lake w Saskatchewan, co spowodowało dużą niepewność dotyczącą podaży uranu i ponad roczny przestój w dostawach wynikających z długoterminowych kontraktów. Wiele elektrowni w obliczu braku dostaw z Kanady zostało zmuszonych do zaopatrywania się na rynku spot co skutecznie wykorzystali pozostali producenci - głównie Energy Fuels, którego cena ostatecznie od początku 2006 roku do połowy 2007 urosła prawie 8 000%. Pomimo ograniczonego wpływu ceny uranu na wytwarzanie energii jądrowej, gwałtowny spadek cen po połowie 2007 roku doprowadził do zakończenia działalności wielu nowych firm, które rosły jak grzyby po deszczu kiedy cena przebiła 50 USD. Natomiast poszukiwania uranu w tym okresie przyniosły wzrost rezerw o 15% co w przyszłych latach ograniczyło możliwe wzrosty.

Czytaj dalej: [[Fukushima - wypadek elektrowni]]

-----------------
#uran 16/06/23
