---
kategoria: "[[Źródła wiedzy]]"
data: 2023-08-30
autor:
  - "[[Gabriel Krynicki]]"
  - "[[Arkadiusz Lenkiewicz]]"
tags:
  - uran
  - energia
  - atom
---
Najbliższe lata, o ile nic się nie zmieni, przyniosą niedobór uranu w energetyce jądrowej. Najpewniej ten niedobór będzie szybko zasypany - choć to zależy od ceny. Szacuje się, że przy poziomie ponad 100 USD / funt opłacalna będzie eksploatacja złóż o szczątkowym nasyceniu (poniżej 0,06%) co z pewnością zwiększy podaż i nagle wyrosną nowe kopalnie. Z drugiej strony pamiętać należy o tym, że od zamówienia do dostarczenia pręta paliwowego - cykl produkcyjny trwa 2 lata. Producenci już zaczęli zwiększać wydobycie ale póki co cena jest za mało atrakcyjna aby mówić o boomie w wydobyciu. Dla wielu firm okres po 2020 jest pierwszym od lat oddechem finansowym i czasem na spłacenie starych długów.

Czytaj dalej: [[Analiza spółek uranowych]]

-----------------
#uran 16/06/23

