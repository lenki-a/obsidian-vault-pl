---
kategoria: "[[Kraje]]"
nazwa: Stany Zjednoczone Ameryki
kontynent: Ameryka Północna
ludność: "332403650"
produkty:
  - Samochody
  - Zaopatrzenie przemysłu
  - Rozwiązania IT
  - Materiały surowe
  - Produkty rolne
indeks giełdowy: SPX
waluta: USD
---
