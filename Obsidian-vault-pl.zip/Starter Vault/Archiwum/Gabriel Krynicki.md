---
imię: Gabriel
nazwisko: Krynicki
telefon: 
email: ""
firma: 
specjalizacja: Spekulacja na rynkach kapitałowych, głównie surowce
data urodzenia: ""
tags: 
url: ""
kategoria: "[[Gabriel Krynicki]]"
twitter: https://x.com/G_Krynicki
---
