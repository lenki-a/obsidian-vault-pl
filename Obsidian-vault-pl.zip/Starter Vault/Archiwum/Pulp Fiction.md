---
kategoria: "[[Filmy]]"
tytuł: Pulp Fiction
data powstania: 
gatunek:
  - Akcja
producent:
  - "[[Miramax]]"
reżyser: "[[Quentin Tarantino]]"
opis: 
url: 
tags:
  - film
ocena: "9"
---
