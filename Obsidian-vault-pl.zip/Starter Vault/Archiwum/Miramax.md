---
kategoria: "[[Firmy]]"
nazwa: Miramax
opis: Produkcja filmów
kraj:
  - "[[USA]]"
specjalizacja: 
właściciel: 
ID: 
url: https://miramax.com
tags:
  - firma
  - organizacja
---
