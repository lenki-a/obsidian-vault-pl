---
kategoria: "[[Kraje]]"
nazwa: Rzeczpospolita Polska
kontynent: Europa
ludność: "37636508"
produkty:
  - Produkty rolne
  - Sprzęt AGD
  - Piwo
  - Okna
  - Meble
  - Automotive
indeks giełdowy: WIG
waluta: PLN
---
