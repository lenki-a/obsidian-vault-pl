---
kategoria: "[[Źródła wiedzy]]"
data: 2023-06-16
autor:
  - "[[Gabriel Krynicki]]"
  - "[[Arkadiusz Lenkiewicz]]"
tags:
  - uran
  - energia
  - atom
---
Ostatnie lata przyniosły wzrosty cen na które się składa kilka czynników:

- budowa wielu nowych elektrowni przyspiesza
- budowa statków z napędem jądrowym przyspiesza jeszcze szybciej
- ETFy Sprotta skupują Uran z rynku spot
- włączenie uranu do zielonej energii przez EU rozpala wyobraźnię inwestorów
- definitywnie skończyły się głowice atomowe do rozebrania

Te czynniki z pewnością pomagają cenie uranu - tym samym windując wyceny spółek giełdowych. Czy ten wzrost będzie utrzymany - to inna historia. Warto nadmienić, że od dołka 2020 roku spółki wydobywcze urosły do 2022 między 500% (Cameco) a 1700% (Uranium Energy Corp). Obecnie za miekkie dno można przyjąć okolice 40 USD gdyż jest to próg rentowności w większości kopalni na świecie. Pisząc “miękkie dno” mam na myśli poziom poniżej którego po kilku miesiącach część kopalni ograniczy małą część wydobycia co delikatnie będzie stymulowało cenę w górę. Ubiegłe lata dobitnie pokazały jak nisko może upaść cena spot co wywołało konsolidację branży na czele z tanimi przejęciami - skutecznie rujnującymi portfele hurra-inwestorów z 2007 roku.

Czytaj dalej: [[Uran - popyt i podaż]]

-----------------
#uran 16/06/23

