---
kategoria: "[[Źródła wiedzy]]"
data: 2024-06-16
autor:
  - "[[Gabriel Krynicki]]"
  - "[[Arkadiusz Lenkiewicz]]"
tags:
  - uran
  - energia
  - atom
---
Łączne zużycie uranu w elektrowniach wynosi wg stanu na 2022 rok około 70 tysięcy ton w 445 reaktorach produkując 398 GWH energii. Aktualnie w trakcie budowy jest 47 nowych reaktorów, a w bardziej odległych planach, włączając Polskę i inne kraje, wdrażające plany energetyki jądrowej - kolejne 80.

![[elektrownie-lista.png]]

Czytaj dalej: [[Przemysł zbrojeniowy - Uran]]

-----------------
#uran 16/06/23