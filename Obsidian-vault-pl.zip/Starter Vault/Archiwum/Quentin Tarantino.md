---
kategoria: "[[Ludzie]]"
imię: Quentin
nazwisko: Tarantino
specjalizacja: Reżyser i producent kina
narodowość: "[[USA]]"
data urodzenia: 
data zgonu: 
firma: 
tags:
  - ludzie
dzieła:
  - "[[Pulp Fiction]]"
  - "[[Pewnego razu w Hollywood]]"
  - "[[Kill Bill vol.1]]"
  - "[[Wściekłe Psy]]"
---
