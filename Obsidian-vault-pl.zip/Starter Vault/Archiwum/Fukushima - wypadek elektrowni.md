---
kategoria: "[[Źródła wiedzy]]"
data: 2023-06-16
autor:
  - "[[Gabriel Krynicki]]"
  - "[[Arkadiusz Lenkiewicz]]"
tags:
  - uran
  - energia
  - atom
---
Drugi, tym razem znacznie mniejszy zryw cen z 2010 roku został zmiażdżony katastrofą nuklearną w Japonii w 2011 roku. Ta doprowadziła do wielu dyskusji na Świecie czy energia jądrowa jest faktycznie bezpieczna - Fukushima miała bardzo zaawansowane systemy bezpieczeństwa, a mimo to doszło do stopienia aż trzech reaktorów i uwolnienia paliwa jądrowego do morza i atmosfery. W konsekwencji Japonia na stałe wyłączyła 41 z 50 reaktorów co zalało rynek spot niepotrzebnym już paliwem jądrowym, którego Japonia miała spore zapasy. Na domiar złego część długoterminowych kontraktów również wylądowała na rynku spotowym co dodatkowo zdołowało ceny na kilka lat. Pokazuje to dobitnie jak niebezpieczne dla uranowych inwestorów mogą być katastrofy nuklearne, których wystąpienie jest niemożliwe do przewidzenia, a konsekwencje mogą trwać długie lata.

Czytaj dalej: [['Szalone lata 20-te' XXI wieku na uranie]]

-----------------
#uran 16/06/23
