---
kategoria: "[[Ludzie]]"
imię: Geoffrey
nazwisko: Seiler
specjalizacja: Dziennikarz i mediaworker
narodowość: "[[USA]]"
data urodzenia: 
data zgonu: 
firma:
  - "[[The Motley Fool]]"
tags:
  - ludzie
dzieła:
---
