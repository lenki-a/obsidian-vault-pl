---
kategoria: "[[Źródła wiedzy]]"
data: 2023-06-16
autor:
  - "[[Gabriel Krynicki]]"
  - "[[Arkadiusz Lenkiewicz]]"
tags:
  - uran
  - energia
  - atom
---
Stosunkowo niewielka ilość uranu jest sprzedawana w ramach kontraktów spot. Nie można bezpośrednio inwestować w uran. Nabywcy i sprzedający zawierają tzw. oferty prywatne. Obecnie rynek ten odpowiada za 9-10% rocznego wydobycia. Reszta to kontrakty od 2 do 20 lat, które zazwyczaj są znacznie poniżej ceny spotowej. Sprawia to, że rynek ten jest mały i podatny na manipulacje cenowe. Zazwyczaj największy popyt na spot jest ze strony nowych elektrowni i tych które nagle planują zwiększyć moc. Nie jest tajemnicą, że zazwyczaj kraje, które zaczynają rozwijać energetykę jądrową są zmuszane do zakupów właśnie na tym rynku zanim podpiszą długoletnie umowy.

![[uran - cena wykres.png]]

Czytaj dalej: [[Bańka uranowa]]

-----------------
#uran 16/06/23

