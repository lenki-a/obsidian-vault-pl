---
kategoria: "[[Waluty]]"
nazwa: 
kraj macierzysty: 
ticker:
---
[Kalkulator walutowy](https://www.podatki.gov.pl/kalkulatory-podatkowe/kalkulator-walut/)

