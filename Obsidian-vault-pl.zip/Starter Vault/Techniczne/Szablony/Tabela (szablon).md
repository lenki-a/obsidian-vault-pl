---
nazwa: 
źródła: 
data: 
autor: 
tags:
  - tabela
kategoria: "[[Tabele]]"
---

|     |     |     |
| --- | --- | --- |
|     |     |     |
|     |     |     |
|     |     |     |
