---
kategoria: "[[Kraje]]"
nazwa: 
kontynent: 
ludność: 
produkty: 
indeks giełdowy: 
waluta:
---
