---
kategoria: "[[Cytaty]]"
autor: 
data: 
url: 
tags:
  - cytat
---
