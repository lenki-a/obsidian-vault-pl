---
kategoria: "[[Konferencje]]"
nazwa: 
dziedzina: 
data i godzina: 
lokalizacja: 
mówca: 
opis: 
url: 
tags:
  - konferencja
---
