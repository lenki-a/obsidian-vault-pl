---
kategoria: "[[Instrumenty finansowe]]"
ticker: 
nazwa: 
opis: 
url: 
tags:
  - giełda
ocena:
---
