---
kategoria: "[[Daily]]"
typ: "[[Dziennik]]"
nazwa: 
data: 
tags:
  - budynek
---
