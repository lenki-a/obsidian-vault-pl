---
kategoria: "[[Spotkania]]"
data i godzina: 
lokalizacja: 
osoba: 
opis: 
url: 
tags:
  - spotkanie
---
# TO-DO

- [ ] 



# Notatka ze spotkania
- 

# Linki


# Materiały