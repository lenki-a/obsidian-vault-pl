---
kategoria: "[[Surowce]]"
nazwa: 
giełda: 
zastosowanie: 
kraje:
---
