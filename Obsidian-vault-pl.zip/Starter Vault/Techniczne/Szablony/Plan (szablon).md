---
kategoria: "[[Plany]]"
nazwa: 
cel: 
autor: 
data: 
deadline: 
url: 
tags:
  - plan
---
