---
kategoria: "[[Budynki]]"
nazwa: 
data powstania: 
architekt: 
inwestor: 
lokalizacja: 
funkcja: 
styl: 
tags:
  - budynek
ocena:
---
