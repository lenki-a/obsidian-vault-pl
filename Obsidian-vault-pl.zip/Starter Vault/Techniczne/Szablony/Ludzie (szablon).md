---
kategoria: "[[Ludzie]]"
imię: 
nazwisko: 
specjalizacja: 
narodowość: 
data urodzenia: 
data zgonu: 
firma: 
tags:
  - ludzie
dzieła:
---
