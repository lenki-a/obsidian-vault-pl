---
kategoria: "[[Prompty]]"
nazwa: 
promptId: 
opis: 
autor: 
tags:
  - prompt
---
content:
{{context}}
prompt:

-TU WPISZ PROMPT-